$(document).ready(function(){
  $(".js-screenshot-slider").owlCarousel({
  	items: 5,
 	center: true,
 	loop: true,
 	autoWidth: true,
 	margin: 0
  });
});