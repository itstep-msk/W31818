$(".js-slider").owlCarousel({
	items: 1
});